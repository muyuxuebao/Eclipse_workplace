// $ANTLR 3.0 SimpleC.g 2007-07-25 20:12:42

#import <Cocoa/Cocoa.h>
#import <ANTLR/ANTLR.h>


#pragma mark Rule return scopes start
#pragma mark Rule return scopes end

#pragma mark Tokens
#define SimpleCLexer_T14	14
#define SimpleCLexer_T11	11
#define SimpleCLexer_T9	9
#define SimpleCLexer_WS	6
#define SimpleCLexer_T12	12
#define SimpleCLexer_T13	13
#define SimpleCLexer_T20	20
#define SimpleCLexer_T7	7
#define SimpleCLexer_T10	10
#define SimpleCLexer_T18	18
#define SimpleCLexer_INT	5
#define SimpleCLexer_T15	15
#define SimpleCLexer_EOF	-1
#define SimpleCLexer_T17	17
#define SimpleCLexer_Tokens	21
#define SimpleCLexer_T16	16
#define SimpleCLexer_T8	8
#define SimpleCLexer_T19	19
#define SimpleCLexer_ID	4

@interface SimpleCLexer : ANTLRLexer {
}


- (void) mT7;
- (void) mT8;
- (void) mT9;
- (void) mT10;
- (void) mT11;
- (void) mT12;
- (void) mT13;
- (void) mT14;
- (void) mT15;
- (void) mT16;
- (void) mT17;
- (void) mT18;
- (void) mT19;
- (void) mT20;
- (void) mID;
- (void) mINT;
- (void) mWS;
- (void) mTokens;



@end